﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class frmCalculoSalario : Form
    {
        public frmCalculoSalario()
        {
            InitializeComponent();
        }

        private void btnVerificaDesconto_Click(object sender, EventArgs e)
        {
            lblDados.Visible = true;

            double descontoINSS = 0;
            double descontoIRPF = 0;
            double salarioLiquido = 0;
            double salarioBruto = 0;
            double salarioFamilia = 0;
            double numeroFilhos = 0;
            double descontoTotal = 0;


            if (txtNomeFunc.Text == String.Empty)
                MessageBox.Show("O nome do funcionário não pode estar vazio");
            else
            {
                if (mskbxSalBruto.Text.Replace(",", "").Trim() == "")
                    MessageBox.Show("Não digitou o salário");

                if (!Double.TryParse(mskbxSalBruto.Text, out salarioBruto) ||
                    (!Double.TryParse(cbxNumFilhos.Text, out numeroFilhos)))
                    MessageBox.Show("É necessário que salário bruto e número de filhos sejam números");
                else
                {
                    if (salarioBruto <= 0)
                        MessageBox.Show("Salário bruto deve ser maior que 0");
                    else
                    {
                        // Cálculo do INSS //

                        if (salarioBruto <= 800.47)
                        {
                            mskbxAliquotaINSS.Text = "7,65%";
                            descontoINSS = (0.0765 * salarioBruto);
                        }
                        else if (salarioBruto <= 1050)
                        {
                            mskbxAliquotaINSS.Text = "8,65%";
                            descontoINSS = (0.0865 * salarioBruto);
                        }
                        else if (salarioBruto <= 1400.77)
                        {
                            mskbxAliquotaINSS.Text = "9,00%";
                            descontoINSS = (0.09 * salarioBruto);
                        }
                        else if (salarioBruto <= 2801.56)
                        {
                            mskbxAliquotaINSS.Text = "11,00%";
                            descontoINSS = (0.11 * salarioBruto);
                        }
                        else
                        {
                            mskbxAliquotaINSS.Text = "Teto";
                            descontoINSS = 308.17;
                        }
                                                                                                                                                                                  
                        mskbxDescontoINSS.Text = descontoINSS.ToString("N2");

                        // Desconto do imposto de Renda //

                        if (salarioBruto <= 1257.12)
                            mskbxAliquotaIRPPF.Text = "0,00";
                        else if (salarioBruto <= 2512.08)
                        {
                            mskbxAliquotaIRPPF.Text = "15,00%";
                            descontoIRPF = (salarioBruto * 0.15);
                        }
                        else
                        {
                            mskbxAliquotaIRPPF.Text = "27,50%";
                            descontoIRPF = (salarioBruto * 0.275);
                        }

                        mskbxDescontoIRPF.Text = descontoIRPF.ToString("N2");

                        // Salário Família //

                        if (numeroFilhos > 0)
                        {
                            if (salarioBruto <= 435.52)
                                salarioFamilia = (22.33 * numeroFilhos);
                            else if (salarioBruto <= 654.61)
                                salarioFamilia = (15.74 * numeroFilhos);
                            else
                                salarioFamilia = 0;
                        }

                        mskbxSalFamilia.Text = salarioFamilia.ToString("N2");

                        salarioLiquido = (salarioBruto - descontoINSS - descontoIRPF + salarioFamilia);

                        mskbxSalLiquido.Text = salarioLiquido.ToString("N2");

                        descontoTotal = (descontoINSS + descontoIRPF);

                        mskbxDescontoTotal.Text = descontoTotal.ToString("N2");

                        lblDados.Text = ("Os descontos do salário") +
                            (rbtnF.Checked ? " da Sra." : " do Sr. ") +
                            (txtNomeFunc.Text + " que é ") +
                            (ckbxCasado.Checked ? "Casado (a)" : "Solteiro (a)") +
                            ("\n" + "e que tem ") +
                            (Convert.ToString(numeroFilhos) + " filho (s) são:");
                    }

                }





            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}