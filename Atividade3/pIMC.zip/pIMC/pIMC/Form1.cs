namespace pIMC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtPesoAtual.Clear();
            txtAltura.Clear();
            txtResultado.Clear();

            txtPesoAtual.Focus();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double peso, altura, imc;

            if (Double.TryParse(txtPesoAtual.Text, out peso) &&
                Double.TryParse(txtAltura.Text, out altura))
            {
                if ((altura <= 0) || (peso <= 0))
                {
                    MessageBox.Show("Valores devem ser maiores que zero.");
                }
                else
                {
                    imc = peso / (Math.Pow(altura, 2)); //Pow (altura, 2) = altura^2 

                    imc = Math.Round(imc, 1); //arredonda 1 casa decimal

                    txtResultado.Text = imc.ToString("N1");//N1 = n�mero com uma casa decimal 

                    if (imc < 18.5)
                        MessageBox.Show("Magreza.");
                    else if (imc <= 24.9)
                        MessageBox.Show("Normal.");
                    else if (imc <= 29.9)
                        MessageBox.Show("Sobrepeso.");
                    else if (imc <= 39.9)
                        MessageBox.Show("Obesidade.");
                    else
                        MessageBox.Show("Obesidade Grave.");
                } 
            }
            else
                MessageBox.Show("Valores inv�lidos!");
        }

        private void lblPeso_Click(object sender, EventArgs e)
        {

        }

        private void txtPesoAtual_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (Char)13)
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }
    }
}