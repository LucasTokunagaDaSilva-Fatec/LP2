﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmenus
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSorteio_Click(object sender, EventArgs e)
        {
            Random aleatorio = new Random();

            int numero1 = Convert.ToInt32(txtNumero1.Text);
            int numero2 = Convert.ToInt32(txtNumero2.Text);
            

            if (numero1 <= numero2)
                txtNumeroSorteado.Text = Convert.ToString(aleatorio.Next(numero1, numero2 + 1)); // + 1: Para pegar os valores menores e igual ao número2 //
           
            else
                MessageBox.Show("Insira um valor em 'Número 1' maior ou igual do que 'Número 2'");



        }
    }
}
