﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmenus
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnQuantidadeCaracteresNum_Click(object sender, EventArgs e)
        {
            int cont, qtde;
            char[] vetorString = rctbxPalavra.Text.ToCharArray();

            qtde = 0;

            for (cont = 0; cont < rctbxPalavra.Text.Length; cont++)
                if (Char.IsNumber(vetorString[cont]))
                    qtde += 1;

            rctbxPalavra.Text = qtde.ToString();
        }

        private void btnPosicaoPrimeiroCaracterBra_Click(object sender, EventArgs e)
        {
            int qtde,cont;
            char[] vetorString = rctbxPalavra.Text.ToCharArray();

            qtde = 1;
            cont = 0;

            while (cont <= rctbxPalavra.Text.Length)
            {
                if (Char.IsWhiteSpace(vetorString[cont])) 
                    break;

                qtde += 1;
                cont += 1;
            }
            rctbxPalavra.Text = qtde.ToString();
        }

        private void btnQuantidadeCaracteresAlfa_Click(object sender, EventArgs e)
        {

            int qtde, cont;
            char[] vetorString = rctbxPalavra.Text.ToCharArray();

            qtde = 0;
            cont = 0;

            foreach (char c in vetorString)
            {
                if (char.IsLetter(vetorString[cont]))
                    qtde += 1;

                cont += 1;
            }
            rctbxPalavra.Text = qtde.ToString();
        }
    }
}
