﻿namespace Pmenus
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmExercicio4));
            this.btnQuantidadeCaracteresNum = new System.Windows.Forms.Button();
            this.btnPosicaoPrimeiroCaracterBra = new System.Windows.Forms.Button();
            this.btnQuantidadeCaracteresAlfa = new System.Windows.Forms.Button();
            this.rctbxPalavra = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnQuantidadeCaracteresNum
            // 
            this.btnQuantidadeCaracteresNum.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(125)))), ((int)(((byte)(255)))));
            this.btnQuantidadeCaracteresNum.Font = new System.Drawing.Font("AmpleSoft Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuantidadeCaracteresNum.Location = new System.Drawing.Point(59, 161);
            this.btnQuantidadeCaracteresNum.Name = "btnQuantidadeCaracteresNum";
            this.btnQuantidadeCaracteresNum.Size = new System.Drawing.Size(181, 101);
            this.btnQuantidadeCaracteresNum.TabIndex = 5;
            this.btnQuantidadeCaracteresNum.Text = "Quantidade Caracteres Numéricos";
            this.btnQuantidadeCaracteresNum.UseVisualStyleBackColor = false;
            this.btnQuantidadeCaracteresNum.Click += new System.EventHandler(this.btnQuantidadeCaracteresNum_Click);
            // 
            // btnPosicaoPrimeiroCaracterBra
            // 
            this.btnPosicaoPrimeiroCaracterBra.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(125)))), ((int)(((byte)(255)))));
            this.btnPosicaoPrimeiroCaracterBra.Font = new System.Drawing.Font("AmpleSoft Bold", 15.75F);
            this.btnPosicaoPrimeiroCaracterBra.Location = new System.Drawing.Point(246, 161);
            this.btnPosicaoPrimeiroCaracterBra.Name = "btnPosicaoPrimeiroCaracterBra";
            this.btnPosicaoPrimeiroCaracterBra.Size = new System.Drawing.Size(181, 101);
            this.btnPosicaoPrimeiroCaracterBra.TabIndex = 6;
            this.btnPosicaoPrimeiroCaracterBra.Text = "Posição Primeiro Dígito Branco";
            this.btnPosicaoPrimeiroCaracterBra.UseVisualStyleBackColor = false;
            this.btnPosicaoPrimeiroCaracterBra.Click += new System.EventHandler(this.btnPosicaoPrimeiroCaracterBra_Click);
            // 
            // btnQuantidadeCaracteresAlfa
            // 
            this.btnQuantidadeCaracteresAlfa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(125)))), ((int)(((byte)(255)))));
            this.btnQuantidadeCaracteresAlfa.Font = new System.Drawing.Font("AmpleSoft Bold", 15.75F);
            this.btnQuantidadeCaracteresAlfa.Location = new System.Drawing.Point(433, 161);
            this.btnQuantidadeCaracteresAlfa.Name = "btnQuantidadeCaracteresAlfa";
            this.btnQuantidadeCaracteresAlfa.Size = new System.Drawing.Size(181, 101);
            this.btnQuantidadeCaracteresAlfa.TabIndex = 7;
            this.btnQuantidadeCaracteresAlfa.Text = "Quantidade Caracteres Alfabéticos";
            this.btnQuantidadeCaracteresAlfa.UseVisualStyleBackColor = false;
            this.btnQuantidadeCaracteresAlfa.Click += new System.EventHandler(this.btnQuantidadeCaracteresAlfa_Click);
            // 
            // rctbxPalavra
            // 
            this.rctbxPalavra.Font = new System.Drawing.Font("AmpleSoft", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rctbxPalavra.Location = new System.Drawing.Point(59, 86);
            this.rctbxPalavra.Name = "rctbxPalavra";
            this.rctbxPalavra.Size = new System.Drawing.Size(555, 42);
            this.rctbxPalavra.TabIndex = 8;
            this.rctbxPalavra.Text = "";
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(675, 312);
            this.Controls.Add(this.rctbxPalavra);
            this.Controls.Add(this.btnQuantidadeCaracteresAlfa);
            this.Controls.Add(this.btnPosicaoPrimeiroCaracterBra);
            this.Controls.Add(this.btnQuantidadeCaracteresNum);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnQuantidadeCaracteresNum;
        private System.Windows.Forms.Button btnPosicaoPrimeiroCaracterBra;
        private System.Windows.Forms.Button btnQuantidadeCaracteresAlfa;
        private System.Windows.Forms.RichTextBox rctbxPalavra;
    }
}