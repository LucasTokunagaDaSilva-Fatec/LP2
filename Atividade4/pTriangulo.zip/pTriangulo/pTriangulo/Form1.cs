namespace pTriangulo
{
    public partial class Form1 : Form
    {
        double A, B, C;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValorA.Clear();
            txtValorB.Clear();
            txtValorC.Clear();

            txtValorA.Focus();
        }

        private void txtValorA_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (Char)13)
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }

        private void txtValorB_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (Char)13)
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }

        private void txtValorB_Leave(object sender, EventArgs e)
        {
            if (txtValorB.Text == "")
                return;

            if (!Double.TryParse(txtValorB.Text, out B))
                MessageBox.Show("Dado Inv�lido!");
        }

        private void txtValorC_Leave(object sender, EventArgs e)
        {
            if (txtValorC.Text == "")
                return;

            if (!Double.TryParse(txtValorC.Text, out C))
                MessageBox.Show("Dado Inv�lido!");
        }

        private void txtValorB_Leave_1(object sender, EventArgs e)
        {
            if (txtValorB.Text == "")
                return;

            if (!Double.TryParse(txtValorB.Text, out B))
                MessageBox.Show("Dado Inv�lido!");
        }

        private void txtValorC_Leave_1(object sender, EventArgs e)
        {
            if (txtValorC.Text == "")
                return;

            if (!Double.TryParse(txtValorC.Text, out C))
                MessageBox.Show("Dado Inv�lido!");
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {

            if (!Double.TryParse(txtValorA.Text, out A) ||
                !Double.TryParse(txtValorB.Text, out B) ||
                !Double.TryParse(txtValorC.Text, out C))
            {
                MessageBox.Show("Valores devem ser num�ricos");
            }
            else
            {
                //Condi��o para ser um tri�ngulo//
                if (Math.Abs(B - C) < A && A < (B + C) &&
                    Math.Abs(A - C) < B && B < (A + C) &&
                    Math.Abs(A - B) < C && C < (A + B))
                {
                    if (A == B && B == C)
                    {
                        MessageBox.Show("O tri�ngulo � EQUIL�TERO!");
                    }
                    else
                    {
                        if (A == B && B != C)
                        {
                            MessageBox.Show("O tri�ngulo � IS�CELES!");
                        }
                        else
                        {
                            MessageBox.Show("O tri�ngulo � ESCALENO!");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Os valores n�o formam um tri�ngulo.");
                }
            }


        }

        private void txtValorA_Leave(object sender, EventArgs e)
        {
            if (txtValorA.Text == "") 
                return;

                if (!Double.TryParse(txtValorA.Text, out A))
                MessageBox.Show("Dado Inv�lido!");
        }
    }
}