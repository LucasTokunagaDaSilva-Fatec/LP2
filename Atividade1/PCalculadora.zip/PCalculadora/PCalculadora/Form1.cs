﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double numero1, numero2;

            if (Double.TryParse(txtNumero1.Text, out numero1) &&
                Double.TryParse(txtNumero2.Text, out numero2))
            {
                double soma;
                soma = numero1 + numero2;
                txtResultado.Text = soma.ToString("");
            }
            else
            {
                MessageBox.Show("Valores inválidos");
                txtNumero1.Focus();
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            double numero1, numero2;

            if (Double.TryParse(txtNumero1.Text, out numero1) &&
                Double.TryParse(txtNumero2.Text, out numero2))
            {
                double subtracao;
                subtracao = numero1 - numero2;
                txtResultado.Text = subtracao.ToString("");
            }
            else
            {
                MessageBox.Show("Valores inválidos");
                txtNumero1.Focus();
            }
        }

        private void lblResultado_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            double numero1, numero2;

            if (Double.TryParse(txtNumero1.Text, out numero1) &&
                Double.TryParse(txtNumero2.Text, out numero2))
            {
                if (numero2 == 0)
                {
                    MessageBox.Show("(Número 2) deve ser diferente de 0.");
                    txtNumero1.Focus();
                }
                else
                {
                    double divisao;
                    divisao = numero1 / numero2;
                    txtResultado.Text = divisao.ToString("");
                }
            }
            else
            {
                MessageBox.Show("Valores inválidos");
                txtNumero1.Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            txtResultado.Text = String.Empty;

            txtNumero1.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtNumero1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (Char)13)
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }

        private void txtNumero2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (Char)13)
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }

        private void txtNumero1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtResultado_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNumero2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnMultiplicacao_Click(object sender, EventArgs e)
        {
            double numero1, numero2;

            if (Double.TryParse(txtNumero1.Text, out numero1) &&
                Double.TryParse(txtNumero2.Text, out numero2))
            {
                double multiplicacao;
                multiplicacao = numero1 * numero2;
                txtResultado.Text = multiplicacao.ToString("");
            }
            else
            {
                MessageBox.Show("Valores inválidos.");
                txtNumero1.Focus();
            }
        }

        private void txtNumero1_TextChanged_1(object sender, EventArgs e)
        {

        }
    }
}
