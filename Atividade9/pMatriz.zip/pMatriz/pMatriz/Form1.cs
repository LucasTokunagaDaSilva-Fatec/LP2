using Microsoft.VisualBasic;
using System.Collections;
using System.Globalization;
using System.Windows.Forms;

namespace pMatriz
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLerInverter_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];

            string aux;
            string saida = "";

            for (var cont = 0; cont < 20; cont++)
            {
                aux = Interaction.InputBox("Digite n�mero", "Entrada de dados ");

                if (!Int32.TryParse(aux, out vetor[cont]))
                {
                    MessageBox.Show("Dado inv�lido");
                    cont--;
                }
                else
                {
                    saida = vetor[cont] + "\n" + saida;
                }
            }
            MessageBox.Show(saida);
        }

        private void btnLerQuantidadePrecoMercadorias_Click(object sender, EventArgs e)
        {
            double[] qtde = new double[10];
            double[] val = new double[10];
            double faturamento = 0;
            string aux;

            for (var cont = 0; cont < 10; cont++)
            {
                aux = Interaction.InputBox("Digite quantidade de mercadoria - " + (cont + 1), "Entrada de quantidades - ");

                if (!double.TryParse(aux, out qtde[cont]))
                {
                    MessageBox.Show("Quantidade inv�lida");

                    cont--;
                }
                else
                {
                    while (val[cont] <= 0)
                    {
                        aux = Interaction.InputBox("Digite o valor da mercadoria - " + (cont + 1), "Entrada de Pre�os - ");

                        if(!double.TryParse(aux, out val[cont]))
                        {
                            MessageBox.Show("Pre�o inv�lido");
                        }
                    }
                    faturamento += qtde[cont] * val [cont]; 
                }
                MessageBox.Show(faturamento.ToString("N2"));
            }
        }

        private void btnMediaAlunos_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20,3];
            string aux;

            for(var lin = 0; lin < 20; lin++)
            {
                for (var col = 0; col < 3; col++)
                {
                    aux = Interaction.InputBox("Digite a nota " + (col + 1) + " do aluno " + (lin + 1), " Entrada de dados");

                    if(!double.TryParse(aux,out notas[lin,col]))
                    {
                        MessageBox.Show("Nota inv�lida");

                        col--;
                    }
                    else
                    {
                        if (!(notas[lin,col] >= 0 && notas[lin,col] <= 10))
                        {
                            MessageBox.Show("Nota inv�lida");

                            col--;
                        }

                    }
                }
                double media = (notas[lin, 0] + notas[lin, 1] + notas[lin, 2]) / 3; // Calcula m�dia  //

                MessageBox.Show("Aluno " + (lin + 1) + ": M�dia " + media.ToString("N2"));
            }

        }

        private void btnVariavelTotal_Click(object sender, EventArgs e)
        {
            string[] Alunos = { "Viviane", "Andr�", "H�lio", "Denise", "Junior", "Leonardo", "Jose", "Nelma", "Tobby" }; 
            Int32 I, Total = 0; 
            Int32 N = Alunos.Length; 
            for (I = 0; I < N; I++) 
            { 
                Total += Alunos[I].Length; 
                MessageBox.Show(Total.ToString()); 
            }
        }

        private void btnArrayList_Click(object sender, EventArgs e)
        {
            string[] Alunos = { "Ana", "Andr�", "D�bora", "F�tima", "Jo�o", "Janete", "Ot�vio", "Marcelo", "Pedro", "Thais" };
            Int32 i, n = Alunos.Length;

            for (i = 0; i < n; i++)
            {
                if (Alunos[i] == "Ot�vio")
                {
                    Alunos[i] = "";
                    MessageBox.Show(Alunos[i+1]);
                    i++;
                }
                else MessageBox.Show(Alunos[i]);
            }
        }

        private void btnNomesPessoas_Click(object sender, EventArgs e)
        {
            frmNomes FrmNomes = new frmNomes();
            FrmNomes.Show();
        }
    }
}