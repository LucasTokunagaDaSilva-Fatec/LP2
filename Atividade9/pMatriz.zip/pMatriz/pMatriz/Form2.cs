﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Intrinsics.X86;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.LinkLabel;

namespace pMatriz
{
    public partial class frmNomes : Form
    {
        public frmNomes()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            int n = 6;
            int i;
            double validar;
            string[] nomes = new string[6];
            string[] aux = new string[6];
            int[] comprimento = new int[100];

            for (i = 0; i < n; i++)
            {
                nomes[i] = Interaction.InputBox("Digite o nome completo: " + (i + 1), "Entrada de dados");
                if (double.TryParse(nomes[i], out validar))
                {
                    MessageBox.Show("Insira apenas Letras");
                    i--;
                }
                else
                {
                    aux[i] = nomes[i].Replace(" ", "");
                    comprimento[i] = aux[i].Length;
                    lstbxNomes.Items.Add("O nome: " + nomes[i] + " tem " + comprimento[i] + " caracteres");
                }

            }
        }
    }
}
