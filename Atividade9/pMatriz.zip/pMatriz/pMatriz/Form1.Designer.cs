﻿namespace pMatriz
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLerInverter = new System.Windows.Forms.Button();
            this.btnLerQuantidadePrecoMercadorias = new System.Windows.Forms.Button();
            this.btnVariavelTotal = new System.Windows.Forms.Button();
            this.btnArrayList = new System.Windows.Forms.Button();
            this.btnMediaAlunos = new System.Windows.Forms.Button();
            this.btnNomesPessoas = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnLerInverter
            // 
            this.btnLerInverter.Font = new System.Drawing.Font("AmpleSoft Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnLerInverter.Location = new System.Drawing.Point(61, 64);
            this.btnLerInverter.Name = "btnLerInverter";
            this.btnLerInverter.Size = new System.Drawing.Size(209, 89);
            this.btnLerInverter.TabIndex = 0;
            this.btnLerInverter.Text = "Ler 20 números e inverter";
            this.btnLerInverter.UseVisualStyleBackColor = true;
            this.btnLerInverter.Click += new System.EventHandler(this.btnLerInverter_Click);
            // 
            // btnLerQuantidadePrecoMercadorias
            // 
            this.btnLerQuantidadePrecoMercadorias.Font = new System.Drawing.Font("AmpleSoft Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnLerQuantidadePrecoMercadorias.Location = new System.Drawing.Point(276, 64);
            this.btnLerQuantidadePrecoMercadorias.Name = "btnLerQuantidadePrecoMercadorias";
            this.btnLerQuantidadePrecoMercadorias.Size = new System.Drawing.Size(209, 89);
            this.btnLerQuantidadePrecoMercadorias.TabIndex = 1;
            this.btnLerQuantidadePrecoMercadorias.Text = "Ler Quantidade e Preço Mercadorias";
            this.btnLerQuantidadePrecoMercadorias.UseVisualStyleBackColor = true;
            this.btnLerQuantidadePrecoMercadorias.Click += new System.EventHandler(this.btnLerQuantidadePrecoMercadorias_Click);
            // 
            // btnVariavelTotal
            // 
            this.btnVariavelTotal.Font = new System.Drawing.Font("AmpleSoft Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnVariavelTotal.Location = new System.Drawing.Point(491, 64);
            this.btnVariavelTotal.Name = "btnVariavelTotal";
            this.btnVariavelTotal.Size = new System.Drawing.Size(209, 89);
            this.btnVariavelTotal.TabIndex = 2;
            this.btnVariavelTotal.Text = "Variável Total";
            this.btnVariavelTotal.UseVisualStyleBackColor = true;
            this.btnVariavelTotal.Click += new System.EventHandler(this.btnVariavelTotal_Click);
            // 
            // btnArrayList
            // 
            this.btnArrayList.Font = new System.Drawing.Font("AmpleSoft Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnArrayList.Location = new System.Drawing.Point(61, 184);
            this.btnArrayList.Name = "btnArrayList";
            this.btnArrayList.Size = new System.Drawing.Size(209, 89);
            this.btnArrayList.TabIndex = 3;
            this.btnArrayList.Text = "ArrayList";
            this.btnArrayList.UseVisualStyleBackColor = true;
            this.btnArrayList.Click += new System.EventHandler(this.btnArrayList_Click);
            // 
            // btnMediaAlunos
            // 
            this.btnMediaAlunos.Font = new System.Drawing.Font("AmpleSoft Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnMediaAlunos.Location = new System.Drawing.Point(276, 184);
            this.btnMediaAlunos.Name = "btnMediaAlunos";
            this.btnMediaAlunos.Size = new System.Drawing.Size(209, 89);
            this.btnMediaAlunos.TabIndex = 4;
            this.btnMediaAlunos.Text = "Média Alunos";
            this.btnMediaAlunos.UseVisualStyleBackColor = true;
            this.btnMediaAlunos.Click += new System.EventHandler(this.btnMediaAlunos_Click);
            // 
            // btnNomesPessoas
            // 
            this.btnNomesPessoas.Font = new System.Drawing.Font("AmpleSoft Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnNomesPessoas.Location = new System.Drawing.Point(491, 184);
            this.btnNomesPessoas.Name = "btnNomesPessoas";
            this.btnNomesPessoas.Size = new System.Drawing.Size(209, 89);
            this.btnNomesPessoas.TabIndex = 5;
            this.btnNomesPessoas.Text = "Nomes Pessoas";
            this.btnNomesPessoas.UseVisualStyleBackColor = true;
            this.btnNomesPessoas.Click += new System.EventHandler(this.btnNomesPessoas_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(787, 350);
            this.Controls.Add(this.btnNomesPessoas);
            this.Controls.Add(this.btnMediaAlunos);
            this.Controls.Add(this.btnArrayList);
            this.Controls.Add(this.btnVariavelTotal);
            this.Controls.Add(this.btnLerQuantidadePrecoMercadorias);
            this.Controls.Add(this.btnLerInverter);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private Button btnLerInverter;
        private Button btnLerQuantidadePrecoMercadorias;
        private Button btnVariavelTotal;
        private Button btnArrayList;
        private Button btnMediaAlunos;
        private Button btnNomesPessoas;
    }
}