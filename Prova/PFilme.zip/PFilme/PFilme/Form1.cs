﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PFilme
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string aux;
            int N = 6;
            double[,] notas = new double[N, 2];
            double media1 = 0;
            double media2 = 0;

            for (var i = 0; i < N; i++)
            {
                aux = Interaction.InputBox("Digite a nota do filme 1 " + (i + 1), "entrada de dados");
                if (!double.TryParse(aux, out notas[i,0]))
                {
                    MessageBox.Show("Quantidade inválida");
                    i--;
                }
                else
                {
                    while (notas[i,1] <= 0)
                    {
                        aux = "";
                        aux = Interaction.InputBox("Digite a nota do filme 2 " + (i + 1), "entrada de dados");

                        if (!double.TryParse(aux, out notas[i,1]))
                        {
                            MessageBox.Show("Preço inválido");
                        }
                    }
                }
                lbxNotas.Items.Add("Pessoa: " + (i + 1) + " Notas filme 1: " + notas[i, 0] + " Notas filme 2: " + notas[i, 1]);
                media1 += (notas[i, 0]);
                media1 /= 2;

                media2 += (notas[i, 1]);
                media2 /= 2;




            }
            lbxNotas.Items.Add("---------------------------");
            lbxNotas.Items.Add("Média Filme 1: " + media1.ToString("N2"));
            lbxNotas.Items.Add("Média filme 2: " + media2.ToString("N2"));



        }
                
        }
    }


